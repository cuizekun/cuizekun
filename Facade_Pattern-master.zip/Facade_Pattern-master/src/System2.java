/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/1713:42
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class System2 {
    public void B(){
        System.out.println("方法B");
    }
}
