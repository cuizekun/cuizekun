/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/1713:41
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class System1 {
    public void A(){

        System.out.println("方法A");
    }
}
