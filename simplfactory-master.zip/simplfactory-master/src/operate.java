/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2216:03
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class operate {
    private double A =0;
    private double B =0;

    @Override
    public String toString() {
        return "factory{" +
                "A=" + A +
                ", B=" + B +
                '}';
    }

    public double getA() {
        return A;
    }

    public void setA(double a) {
        A = a;
    }

    public double getB() {
        return B;
    }

    public void setB(double b) {
        B = b;
    }
    public double getresult(){
        double result=0;
        return result;
    }
}
