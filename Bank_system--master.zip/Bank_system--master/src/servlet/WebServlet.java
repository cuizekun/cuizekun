package servlet;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2420:40
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public @interface WebServlet {
}
