package service;

import pojo.User;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2510:42
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public interface service {
    User check(String uname, String pwd);
}
