package primary;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2414:56
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class peopletest {
    public static void main(String[] args) {
        people p = new people("小陈");
        p.toString();
        p.hat();
        p.shirt();
        p.jeans();
        p.shoes();
    }
}
