package senior;

public class tshirt extends finery {
    public void show(){
        super.show();
        System.out.println("穿寸衫");

    }
}
