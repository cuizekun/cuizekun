package senior;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2416:07
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class hat extends finery {
    public void show(){
        super.show();
        System.out.println("带了个帽子");

    }
}
