package senior;

public class tie extends finery{
    public void show() {
        super.show();
        System.out.println("穿领带");
    }
}
