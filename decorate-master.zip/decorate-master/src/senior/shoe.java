package senior;

public class shoe extends finery {
    public void show(){
        super.show();
        System.out.println("穿匡威");
    }
}
