package senior;

public class people {
    private String name;

    public people() {}

    public people(String name) {

        this.name = name;
    }

    public  void  show(){
        System.out.println("我是"+name);
    }
}
