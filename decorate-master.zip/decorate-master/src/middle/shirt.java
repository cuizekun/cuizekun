package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2415:10
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class shirt implements clothes {
    @Override
    public void show() {
        System.out.println("穿了件T恤");
    }
}
