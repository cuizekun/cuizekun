package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2415:12
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class shoes implements clothes {
    @Override
    public void show() {
        System.out.println("穿了个鞋子");
    }
}
