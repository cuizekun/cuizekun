package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2415:11
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class jeans implements clothes {
    @Override
    public void show() {
        System.out.println("穿了件牛仔裤");
    }
}
