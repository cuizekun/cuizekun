package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2415:07
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
interface clothes {
    public void show();

}
