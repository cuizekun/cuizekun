package 雷锋工厂方法模式;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/320:18
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class leifeng {
    public void sweep(){
        System.out.println("擦桌子");
    }

    public void  clean(){
        System.out.println("打扫");
    }

    public void buy_friut(){
        System.out.println("卖水果");
    }
}
