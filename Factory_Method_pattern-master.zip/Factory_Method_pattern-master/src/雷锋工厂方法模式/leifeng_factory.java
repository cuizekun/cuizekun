package 雷锋工厂方法模式;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/320:24
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public interface leifeng_factory {
    public leifeng createleifeng();
}
