package 雷锋工厂方法模式;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/320:21
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class undergraduate extends leifeng {

}
