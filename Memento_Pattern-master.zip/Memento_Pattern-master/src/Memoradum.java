/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/6/117:37
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public interface Memoradum {

}
