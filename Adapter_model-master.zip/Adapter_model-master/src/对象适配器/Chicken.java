package 对象适配器;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/3016:55
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public interface Chicken {
    void fly();
    void jiji();
}
